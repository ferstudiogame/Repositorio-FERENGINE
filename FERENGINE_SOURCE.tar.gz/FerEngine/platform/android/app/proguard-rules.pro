# FERENGINE JNI entry points are referenced by their native symbol names.
# Keep the bridge class stable if minification is enabled in a future release.
-keep class com.ferstudio.ferengine.NativeBridge { *; }
