#include <jni.h>

#include "ferengine/core/runtime.hpp"

#include <memory>
#include <mutex>

namespace {

std::mutex gRuntimeMutex;
std::unique_ptr<ferengine::core::EngineRuntime> gRuntime;

ferengine::core::EngineRuntime& runtime() {
    std::lock_guard lock(gRuntimeMutex);
    if (!gRuntime) {
        gRuntime = std::make_unique<ferengine::core::EngineRuntime>();
    }
    return *gRuntime;
}

} // namespace

extern "C" JNIEXPORT jboolean JNICALL
Java_com_ferstudio_ferengine_NativeBridge_nativeInitialize(JNIEnv*, jobject) {
    return runtime().initialize() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_ferstudio_ferengine_NativeBridge_nativeResume(JNIEnv*, jobject) {
    return runtime().resume() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_ferstudio_ferengine_NativeBridge_nativePause(JNIEnv*, jobject) {
    return runtime().pause() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_ferstudio_ferengine_NativeBridge_nativeShutdown(JNIEnv*, jobject) {
    runtime().shutdown();
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_ferstudio_ferengine_NativeBridge_nativeDiagnosticSummary(JNIEnv* env, jobject) {
    const std::string summary = runtime().diagnosticSummary();
    return env->NewStringUTF(summary.c_str());
}
