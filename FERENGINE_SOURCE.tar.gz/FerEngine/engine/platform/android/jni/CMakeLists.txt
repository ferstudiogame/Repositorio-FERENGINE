add_library(ferengine_android SHARED
    ferengine_jni.cpp
)

target_compile_features(ferengine_android PRIVATE cxx_std_20)
target_link_libraries(ferengine_android PRIVATE ferengine_core android log)
target_compile_options(ferengine_android PRIVATE -Wall -Wextra -Wpedantic)
