#include "ferengine/core/runtime.hpp"

#include <sstream>

namespace ferengine::core {

bool EngineRuntime::initialize() {
    std::lock_guard lock(mutex_);
    if (state_ == RuntimeState::Ready || state_ == RuntimeState::Running || state_ == RuntimeState::Paused) {
        return true;
    }
    if (state_ == RuntimeState::Stopped) {
        return false;
    }
    state_ = RuntimeState::Ready;
    ++lifecycleTransitions_;
    return true;
}

bool EngineRuntime::resume() {
    std::lock_guard lock(mutex_);
    if (state_ == RuntimeState::Running) {
        return true;
    }
    if (state_ != RuntimeState::Ready && state_ != RuntimeState::Paused) {
        return false;
    }
    state_ = RuntimeState::Running;
    ++lifecycleTransitions_;
    return true;
}

bool EngineRuntime::pause() {
    std::lock_guard lock(mutex_);
    if (state_ == RuntimeState::Paused) {
        return true;
    }
    if (state_ != RuntimeState::Running) {
        return false;
    }
    state_ = RuntimeState::Paused;
    ++lifecycleTransitions_;
    return true;
}

void EngineRuntime::shutdown() {
    std::lock_guard lock(mutex_);
    if (state_ != RuntimeState::Stopped) {
        state_ = RuntimeState::Stopped;
        ++lifecycleTransitions_;
    }
}

RuntimeSnapshot EngineRuntime::snapshot() const {
    std::lock_guard lock(mutex_);
    return RuntimeSnapshot{state_, lifecycleTransitions_};
}

std::string EngineRuntime::diagnosticSummary() const {
    const RuntimeSnapshot current = snapshot();
    std::ostringstream stream;
    stream << "FerEngine Core " << Version
           << " | C++20 | state=" << toString(current.state)
           << " | transitions=" << current.lifecycleTransitions;
    return stream.str();
}

const char* toString(const RuntimeState state) noexcept {
    switch (state) {
        case RuntimeState::Cold: return "COLD";
        case RuntimeState::Ready: return "READY";
        case RuntimeState::Running: return "RUNNING";
        case RuntimeState::Paused: return "PAUSED";
        case RuntimeState::Stopped: return "STOPPED";
    }
    return "UNKNOWN";
}

} // namespace ferengine::core
