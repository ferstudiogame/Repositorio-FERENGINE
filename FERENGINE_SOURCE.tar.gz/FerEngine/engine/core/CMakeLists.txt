add_library(ferengine_core STATIC
    src/runtime.cpp
)

target_include_directories(ferengine_core
    PUBLIC
        ${CMAKE_CURRENT_SOURCE_DIR}/include
)

target_compile_features(ferengine_core PUBLIC cxx_std_20)
set_target_properties(ferengine_core PROPERTIES POSITION_INDEPENDENT_CODE ON)

if(MSVC)
    target_compile_options(ferengine_core PRIVATE /W4 /permissive-)
else()
    target_compile_options(ferengine_core PRIVATE -Wall -Wextra -Wpedantic -Wconversion -Wsign-conversion)
endif()
