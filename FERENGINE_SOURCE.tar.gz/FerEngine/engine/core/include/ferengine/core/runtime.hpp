#pragma once

#include <cstdint>
#include <mutex>
#include <string>

namespace ferengine::core {

enum class RuntimeState : std::uint8_t {
    Cold,
    Ready,
    Running,
    Paused,
    Stopped,
};

struct RuntimeSnapshot {
    RuntimeState state{RuntimeState::Cold};
    std::uint64_t lifecycleTransitions{0};
};

class EngineRuntime final {
public:
    static constexpr const char* Version = "0.1.0";

    [[nodiscard]] bool initialize();
    [[nodiscard]] bool resume();
    [[nodiscard]] bool pause();
    void shutdown();

    [[nodiscard]] RuntimeSnapshot snapshot() const;
    [[nodiscard]] std::string diagnosticSummary() const;

private:
    mutable std::mutex mutex_;
    RuntimeState state_{RuntimeState::Cold};
    std::uint64_t lifecycleTransitions_{0};
};

[[nodiscard]] const char* toString(RuntimeState state) noexcept;

} // namespace ferengine::core
