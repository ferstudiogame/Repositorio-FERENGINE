# FERENGINE

**Motor 3D independiente para Android, con runtime C++20 y editor nativo Kotlin.**

> Estado del repositorio: **base de Fase 1 en desarrollo**. No es todavía un motor 3D utilizable: el runtime nativo y la shell Android están iniciados; el renderizador Vulkan, el sistema de escenas y las herramientas del editor aún no están implementados.

## Objetivo

Crear tecnología propia para videojuegos 3D sin usar Godot, Unity ni Unreal como runtime. La experiencia inicial de desarrollo está pensada para Android en horizontal, con una arquitectura C++ portable, integración nativa Kotlin/JNI y compilaciones reproducibles mediante GitHub Actions.

## Estado verificado en esta entrega

- Núcleo C++20 independiente del framework Android.
- Máquina de estados de ciclo de vida del runtime.
- Pruebas nativas con CMake/CTest.
- Aplicación Android nativa Kotlin + JNI preparada para compilar.
- Orientación horizontal solicitada en el manifiesto y reforzada en la Activity.
- Modo inmersivo con API moderna de Android y alternativa para versiones anteriores.
- Interfaz inicial nativa que informa explícitamente qué módulos todavía no existen.
- Workflow de GitHub Actions para pruebas del núcleo y APK de depuración.

**No verificado todavía:** compilación Android, instalación, ejecución en un teléfono, comportamiento en distintos fabricantes, ni renderizado Vulkan. El entorno donde se preparó esta base no contiene Android SDK, Android NDK, Gradle ni ADB.

## Arquitectura resumida

- `engine/core`: runtime portable C++20.
- `engine/platform/android/jni`: puente JNI entre Kotlin y el núcleo.
- `platform/android/app`: aplicación y editor nativo Android.
- `tests`: pruebas automatizadas del núcleo.
- `docs`: arquitectura, decisiones, compilación, gráficos, compatibilidad y roadmap.
- `.github/workflows`: integración continua.

## Compilar y probar el núcleo en Linux

Requisitos: CMake 3.22.1 o posterior, Ninja y un compilador C++20.

```bash
cmake -S . -B build -G Ninja -DFERENGINE_BUILD_TESTS=ON
cmake --build build --parallel
ctest --test-dir build --output-on-failure
```

## Compilar Android

La compilación Android se ejecuta con Gradle 9.6.0, Android Gradle Plugin 9.5.0, SDK Platform 36, Build Tools 36.0.0, NDK 28.2.13676358 y CMake 3.31.6. Consulta [`docs/BUILD_ANDROID.md`](docs/BUILD_ANDROID.md).

El workflow usa Gradle instalado por `gradle/actions/setup-gradle`, por eso esta primera entrega no incorpora un `gradle-wrapper.jar` descargado sin poder verificarlo. En un entorno Android Studio/Gradle se puede generar el wrapper oficial con:

```bash
gradle -p platform/android wrapper --gradle-version 9.6.0
```

## Decisiones importantes

- Vulkan es el backend gráfico objetivo, pero se detectará la capacidad real del controlador en cada dispositivo. No se asumirá que la versión de Android garantiza Vulkan 1.3.
- OpenGL ES 3.x queda como ruta de compatibilidad planificada; aún no hay backend gráfico operativo.
- La orientación horizontal es la preferencia y el bloqueo solicitado para teléfonos. Android 16+ ignora restricciones de orientación en ciertos dispositivos de pantalla grande, y Android 17 elimina la excepción temporal para apps con target API 37. La interfaz tendrá que seguir siendo adaptable.
- Android permite mostrar temporalmente las barras del sistema mediante gestos; ninguna app normal puede prometer ocultarlas permanentemente.
- No se eligió todavía licencia para el código de FERENGINE. No se concede una licencia implícita por este repositorio.

## Licencia

Pendiente de decisión del propietario. Consulta [`LICENSES/PROJECT_LICENSE_PENDING.md`](LICENSES/PROJECT_LICENSE_PENDING.md).
